# Thunderbird-Filters-Replication-Plugin
Plugin para Thunderbird que permite la replicación de filtros de mensajes entre múltiples cuentas de correo
